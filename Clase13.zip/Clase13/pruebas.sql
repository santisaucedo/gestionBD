insert into clientes (nombre,apellido,tipo_doc,numero_doc,fenaci) values 
    ('Juan','Perez','DNI','99999999','1990-05-10');

select CURDATE();
select * from clientes;
insert into clientes (id,nombre,apellido,tipo_doc,numero_doc,fenaci) values 
    (1,'Juan','Perez','DNI','99999999','1990-05-10');

insert into clientes (nombre,apellido,tipo_doc,numero_doc,fenaci) values 
    ('Roxana Roxana Roxana Roxana ','Perez','DNI','99999991','1990-05-10');
