use negocio;

-- consulta de catalogo de trigger
select * from information_schema.TRIGGERS;

drop TRIGGER if EXISTS tr_test;
CREATE TRIGGER tr_test
    AFTER INSERT ON clientes FOR EACH ROW           -- after before -- insert delete o update
    BEGIN
        update articulos set stock=0 WHERE id=(NEW.id-10);   -- NEW  OLD
    END; 

select * from articulos;

select * from clientes;
INSERT INTO clientes (nombre, apellido, tipo_doc, numero_doc, fenaci, telefono, email, comentarios, activo)
VALUES
  ('Juan', 'Pérez', 'DNI', '23398778', '1990-05-15', '123456789', 'juan.perez@example.com', 'Cliente frecuente', true);
  

-- Auditoria de tablas
DROP TABLE IF EXISTS control_auditoria;
CREATE TABLE control_auditoria(
    id int AUTO_INCREMENT PRIMARY KEY,
    tabla varchar(50) not null,
    evento ENUM ('INSERT','DELETE','UPDATE') NOT NULL,
    id_registro INT,
    fecha date,
    hora time,
    usuario VARCHAR(50),
    ip VARCHAR(50)
);

-- fecha
SELECT curdate();
-- hora
select CURTIME();
SELECT user,host FROM mysql.user;
SELECT user();
SELECT ;

DROP TRIGGER IF EXISTS TR_clientes_insert;
CREATE TRIGGER TR_clientes_insert
AFTER INSERT ON clientes FOR EACH ROW
    BEGIN
        INSERT INTO control_auditoria 
            (tabla, evento, id_registro, fecha, hora, usuario, ip)
            VALUES
            ('clientes','INSERT', NEW.id, CURDATE(), CURTIME(),
                USER(), '');
    END; 

INSERT INTO clientes (nombre, apellido, tipo_doc, numero_doc, fenaci, telefono, email, comentarios, activo)
VALUES
  ('Juan', 'Pérez', 'DNI', '11398778', '1990-05-15', '123456789', 'juan.perez@example.com', 'Cliente frecuente', true);

select * from clientes;
select * from control_auditoria;

DROP TRIGGER IF EXISTS TR_clientes_delete;
CREATE TRIGGER TR_clientes_delete
AFTER DELETE ON clientes FOR EACH ROW
    BEGIN
        INSERT INTO control_auditoria 
            (tabla, evento, id_registro, fecha, hora, usuario, ip)
            VALUES
            ('clientes','DELETE', OLD.id, CURDATE(), CURTIME(),
                USER(), '');
    END; 

delete from clientes where id=23;
select * from control_auditoria;

DROP TRIGGER IF EXISTS TR_clientes_update;
CREATE TRIGGER TR_clientes_update
AFTER UPDATE ON clientes FOR EACH ROW
    BEGIN
        INSERT INTO control_auditoria 
            (tabla, evento, id_registro, fecha, hora, usuario, ip)
            VALUES
            ('clientes','UPDATE', OLD.id, CURDATE(), CURTIME(),
                USER(), '');
    END; 

update clientes set nombre='Lorena' where id=12;
SELECT * from control_auditoria;