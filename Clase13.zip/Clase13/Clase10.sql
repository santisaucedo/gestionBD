-- Active: 1729293266338@@127.0.0.1@3306@negocio
use negocio;
DROP PROCEDURE if EXISTS sp_clientes_insert;
CREATE PROCEDURE sp_clientes_insert(
    in p_nombre varchar(25),
    in p_apellido varchar(25),
    in p_tipo_doc ENUM('DNI','LC','LE','PASS'),
    in p_numero_doc varchar(10),
    in p_fenaci date,
    in p_telefono varchar(20),
    in p_email varchar(60),
    in p_comentarios varchar(250)
    )
BEGIN
    insert into clientes 
        (nombre,apellido,tipo_doc,numero_doc,fenaci,telefono,email,comentarios)
        values(
            p_nombre,p_apellido,p_tipo_doc,p_numero_doc,p_fenaci,
            p_telefono,p_email,p_comentarios
        );
END; $$

call sp_clientes_insert(
                            'Lautaro',
                            'Martinez',
                            'DNI',
                            '12398766',
                            '2020/10/10',
                            '2132132',
                            'toro@gmail',
                            ''
                        );

DROP PROCEDURE IF EXISTS sp_clientes_delete;
CREATE PROCEDURE sp_clientes_delete(in p_id int)
BEGIN
    -- delete from clientes where id=p_id;
    update clientes set activo=false where id=p_id;
END; $$                    

CALL sp_clientes_delete(20);

DROP PROCEDURE IF EXISTS sp_clientes_update;
CREATE PROCEDURE sp_clientes_update(
    in p_id int,
    in p_nombre varchar(25),
    in p_apellido varchar(25),
    in p_tipo_doc ENUM('DNI','LC','LE','PASS'),
    in p_numero_doc varchar(10),
    in p_fenaci date,
    in p_telefono varchar(20),
    in p_email varchar(60),
    in p_comentarios varchar(250)
)
BEGIN
    update clientes set nombre=p_nombre, apellido=p_apellido,
        tipo_doc=p_tipo_doc, numero_doc=p_numero_doc, fenaci=p_fenaci,
        telefono=p_telefono, email=p_email, comentarios=p_comentarios 
        where id=p_id;
END; $$

CALL sp_clientes_update(
                            1,
                            'raul',
                            'pereyra',
                            'DNI',
                            '12345678',
                            '1990-05-15',
                            '123456789',
                            'Raul@gmail',
                            ''
                        );
/*
        crear los procedimientos    sp_facturas_insert, 
                                    sp_facturas_delete, 
                                    sp_facturas_update,
                                    sp_articulos_insert,
                                    sp_articulos_delete,
                                    sp_articulos_update
*/

select CURDATE();
select * from clientes;
/*
CREATE TABLE clientes(
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(25) NOT NULL, -- CHECK(LENGTH(nombre)>=3),
    apellido VARCHAR(25) NOT NULL, -- CHECK(LENGTH(apellido)>=3),
    tipo_doc ENUM('DNI','LC','LE','PASS') NOT NULL DEFAULT 'DNI',
    numero_doc VARCHAR(10) NOT NULL, -- CHECK(LENGTH(numero_doc)>=5),
    fenaci DATE NOT NULL,
    telefono VARCHAR(20),
    email VARCHAR(60),
    comentarios VARCHAR(250),
    activo BOOLEAN NOT NULL DEFAULT true
);
*/