use negocio;

DROP FUNCTION IF EXISTS f_calcular_iva;

CREATE FUNCTION f_calcular_iva(monto DOUBLE)
RETURNS DOUBLE
BEGIN
    RETURN ROUND(monto*1.21,2);
END;

DESCRIBE articulos;
select id,descripcion, costo,precio, f_calcular_iva(precio) 'valor_iva',
    precio+f_calcular_iva(precio) 'precio_con_iva',stock, stock_min, stock_max
    from articulos;

/*
        Desafio.

    - Armar una función llamada f_cantidad_a_reponer() en donde ingresa como 
        parámetro el id de un articulo y devuelve la cantidad de stock que se
        debe reponer (dicho articulo), en caso de no reponer devuelve 0.
    - Armar una función llamada f_costo_de_reponer() en donde ingrese como 
        parámetro el id de un articulo y devuelve el costo de reposición de
        dicho articulo, en caso de no reponer devuelve 0.  

*/
