-- Active: 1729293266338@@127.0.0.1@3306@negocio
use negocio;

-- Objeto Funciones

-- funciones de sql
SELECT * FROM information_schema.SQL_FUNCTIONS;

-- UDF (User Define Functions) Funciones definidas por el usuario
SELECT * from information_schema.ROUTINES
    WHERE ROUTINE_TYPE='FUNCTION'
    AND ROUTINE_SCHEMA='negocio';

DROP FUNCTION IF EXISTS F_test;
CREATE FUNCTION F_test()
RETURNS DOUBLE 
BEGIN
    RETURN PI();
END;