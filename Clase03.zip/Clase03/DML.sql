use negocio;
-- Clientes
INSERT INTO clientes (nombre, apellido, tipo_doc, numero_doc, fenaci, telefono, email, comentarios, activo)
VALUES
  ('Juan', 'Pérez', 'DNI', '12345678', '1990-05-15', '123456789', 'juan.perez@example.com', 'Cliente frecuente', true),
  ('María', 'González', 'LC', '87654321', '1985-11-20', '987654321', 'maria.gonzalez@example.com', 'Nuevo cliente', true),
  ('Pedro', 'Sánchez', 'LE', '54321987', '1992-02-28', '456789123', 'pedro.sanchez@example.com', 'Cliente ocasional', true),
  ('Ana', 'Rodríguez', 'PASS', '98765432', '1978-06-10', '789456123', 'ana.rodriguez@example.com', 'Cliente VIP', true),
  ('Luis', 'Gómez', 'DNI', '45678912', '1995-09-05', '321987654', 'luis.gomez@example.com', 'Cliente nuevo', true),
  ('Sofía', 'Fernández', 'LC', '87912345', '1988-03-18', '654789123', 'sofia.fernandez@example.com', 'Cliente antiguo', true),
  ('Carlos', 'Hernández', 'LE', '23456789', '1991-07-25', '159753852', 'carlos.hernandez@example.com', 'Cliente recurrente', true),
  ('Lucía', 'Ramírez', 'PASS', '98741236', '1982-12-01', '963852741', 'lucia.ramirez@example.com', 'Cliente de prueba', true),
  ('Miguel', 'Torres', 'DNI', '56789123', '1997-04-30', '753951753', 'miguel.torres@example.com', 'Cliente potencial', true),
  ('Camila', 'Suárez', 'LC', '89012345', '1993-08-15', '852753951', 'camila.suarez@example.com', 'Cliente frecuente', true),
  ('Javier', 'Castillo', 'LE', '45123789', '1990-11-10', '951753852', 'javier.castillo@example.com', 'Cliente ocasional', true),
  ('Gabriela', 'Díaz', 'PASS', '78945612', '1986-02-22', '753951753', 'gabriela.diaz@example.com', 'Cliente VIP', true),
  ('Ricardo', 'Morales', 'DNI', '12789654', '1994-06-01', '852753951', 'ricardo.morales@example.com', 'Cliente nuevo', true),
  ('Valentina', 'Gutiérrez', 'LC', '98765432', '1989-09-28', '753951753', 'valentina.gutierrez@example.com', 'Cliente antiguo', true),
  ('David', 'Ramos', 'LE', '45612789', '1993-03-15', '852753951', 'david.ramos@example.com', 'Cliente recurrente', true),
  ('Natalia', 'Ortiz', 'PASS', '78963215', '1985-12-05', '753951753', 'natalia.ortiz@example.com', 'Cliente de prueba', true),
  ('Alejandro', 'Jiménez', 'DNI', '23456789', '1998-07-20', '852753951', 'alejandro.jimenez@example.com', 'Cliente potencial', true),
  ('Daniela', 'Castillo', 'LC', '78965412', '1991-04-12', '753951753', 'daniela.castillo@example.com', 'Cliente frecuente', true),
  ('Sebastián', 'Reyes', 'LE', '12345678', '1987-11-08', '852753951', 'sebastian.reyes@example.com', 'Cliente ocasional', true),
  ('Valeria', 'Herrera', 'PASS', '98765123', '1996-08-25', '753951753', 'valeria.herrera@example.com', 'Cliente VIP', true);

-- Artículos
INSERT INTO articulos (descripcion, costo, precio, stock, stock_min, stock_max)
VALUES
  ('Producto A', 10.50, 15.99, 100, 20, 150),
  ('Producto B', 15.75, 22.99, 50, 10, 100),
  ('Producto C', 8.25, 12.99, 75, 15, 120),
  ('Producto D', 20.00, 29.99, 30, 5, 80),
  ('Producto E', 12.50, 18.99, 90, 20, 150),
  ('Producto F', 18.00, 26.99, 40, 8, 90),
  ('Producto G', 9.75, 14.99, 60, 12, 110),
  ('Producto H', 25.00, 34.99, 20, 3, 60),
  ('Producto I', 14.25, 21.99, 80, 18, 140),
  ('Producto J', 16.50, 24.99, 45, 9, 95),
  ('Producto K', 11.00, 16.99, 70, 14, 130),
  ('Producto L', 22.75, 32.99, 25, 4, 70),
  ('Producto M', 13.50, 19.99, 85, 19, 145),
  ('Producto N', 19.25, 28.99, 35, 7, 85),
  ('Producto O', 10.75, 15.99, 65, 13, 115),
  ('Producto P', 23.50, 33.99, 15, 2, 50),
  ('Producto Q', 12.00, 17.99, 95, 20, 155),
  ('Producto R', 17.25, 25.99, 55, 11, 105),
  ('Producto S', 9.00, 13.99, 80, 16, 135),
  ('Producto T', 21.75, 31.99, 30, 5, 75);

-- Facturas
INSERT INTO facturas (letra, numero, fecha, monto, id_cliente)
VALUES
  ('A', 1001, '2023-01-15', 150.00, 1),
  ('A', 1002, '2023-02-10', 250.75, 2),
  ('B', 2001, '2023-03-05', 120.50, 3),
  ('B', 2002, '2023-04-01', 300.00, 4),
  ('A', 1003, '2023-05-20', 180.25, 5),
  ('C', 3001, '2023-06-12', 95.75, 6),
  ('B', 2003, '2023-07-08', 270.50, 7),
  ('A', 1004, '2023-08-03', 215.00, 8),
  ('C', 3002, '2023-09-18', 135.25, 9),
  ('B', 2004, '2023-10-25', 325.75, 10),
  ('A', 1005, '2023-11-07', 160.50, 11),
  ('C', 3003, '2023-12-02', 110.00, 12),
  ('B', 2005, '2023-01-22', 290.25, 13),
  ('A', 1006, '2023-02-15', 205.00, 14),
  ('C', 3004, '2023-03-28', 150.75, 15),
  ('B', 2006, '2023-04-19', 350.50, 16),
  ('A', 1007, '2023-05-11', 175.25, 17),
  ('C', 3005, '2023-06-06', 120.00, 18),
  ('B', 2007, '2023-07-27', 280.75, 19),
  ('A', 1008, '2023-08-22', 190.50, 20);

-- Detalles
INSERT INTO detalles (id_articulo, id_factura, cantidad, valor_unidad)
VALUES
  (1, 1, 5, 15.99),
  (2, 1, 3, 22.99),
  (3, 2, 8, 12.99),
  (4, 2, 2, 29.99),
  (5, 3, 7, 18.99),
  (6, 3, 4, 26.99),
  (7, 4, 6, 14.99),
  (8, 4, 1, 34.99),
  (9, 5, 9, 21.99),
  (10, 5, 2, 24.99),
  (11, 6, 5, 16.99),
  (12, 6, 3, 32.99),
  (13, 7, 8, 19.99),
  (14, 7, 4, 28.99),
  (15, 8, 6, 15.99),
  (16, 8, 2, 33.99),
  (17, 9, 7, 17.99),
  (18, 9, 3, 25.99),
  (19, 10, 5, 13.99),
  (20, 10, 1, 31.99);