-- Active: 1729293266338@@127.0.0.1@3306@negocio
-- stored procedures - procedimientos almacenados

DELIMITER $$
DROP PROCEDURE IF EXISTS sp_test;
CREATE PROCEDURE sp_test()
BEGIN
    SELECT 'Hola Mundo';
END; $$

DROP PROCEDURE IF EXISTS sp_test2;



CREATE PROCEDURE sp_test2()
BEGIN
    SELECT 'Hoy es viernes';
END; $$

DROP PROCEDURE if EXISTS sp_test3;
CREATE PROCEDURE sp_test3(in p_nombre varchar(30))
BEGIN
    SELECT CONCAT('Hola ',p_nombre);
END; $$

CALL sp_test();
CALL sp_test2();
CALL sp_test3('Carlos');

select 'Hola Mundo';
select version();

-- crear un stored que ingrese el id de un producto y imprima 
--      el articulo mas precio con iva y si hay que reponer, 
--      cantidad a reponer y costo de y costo de reposición

DROP PROCEDURE IF EXISTS sp_Articulos_Reponer;
CREATE PROCEDURE sp_Articulos_Reponer(in p_id int)
BEGIN
    select  id, 
        descripcion, 
        costo, 
        precio, 
        round(precio * 1.21,2) precio_final,
        stock, 
        stock_min, 
        stock_max,
        if(stock<=stock_min,'si','no') reponer_producto,
        if(stock<=stock_min,stock_max-stock,0) cantidad_a_reponer,
        if(stock<=stock_min,round((stock_max-stock)*costo,2),0) costo_de_reponer
        from articulos
        where id=p_id;
END; $$

CALL sp_Articulos_Reponer(2);

select * from articulos;

-- encapsulamiento de tablas
